(function () {
  const TARGET_APP = "app://m.fast.com";

  function openFast() {
    if (!navigator.mozApps || !navigator.mozApps.mgmt) {
      console.log("mozApps not available");
      return;
    }

    navigator.mozApps.mgmt.getAll().then(apps => {
      const app = apps.find(a => a.origin === TARGET_APP);
      if (app) {
        app.launch();
      } else {
        console.log("Fast.com app not found:", TARGET_APP);
      }
    });
  }

  window.addEventListener("keydown", e => {
    if (e.key === "3") {
      openFast();
    }
  });
})();
