(function () {

  function is1Key(e) {
    return e.key === "1";
  }

  function rebootDevice() {
    if (window.Wallace && typeof Wallace.reboot === "function") {
      Wallace.reboot();
    } else {
      console.log("Wallace.reboot not available");
    }
  }

  document.addEventListener("keydown", function (e) {
    if (!is1Key(e)) return;

    e.preventDefault();
    e.stopPropagation();

    rebootDevice();

  }, true);

})();
