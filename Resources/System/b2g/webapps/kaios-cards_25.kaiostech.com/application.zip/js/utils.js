'use strict';if(typeof window.l10nGet!=='function'){window.l10nGet=function(l10nId){return navigator.mozL10n.get(l10nId);};}
if(typeof String.prototype.startsWith!=='function'){String.prototype.startsWith=function(prefix){return prefix===this.slice(0,prefix.length);};}
if(typeof String.prototype.contains!=='function'){String.prototype.contains=function(substr){return-1!==this.indexOf(substr);};}
if(typeof Array.prototype.contains!=='function'){Array.prototype.contains=function(item){return-1!==this.indexOf(item);};}
if(typeof Array.prototype.bsearch!=='function'){Array.prototype.bsearch=function(key,cmp){let low=0;let high=this.length-1;while(low<=high){const mid=low+high>>1;const result=cmp(key,this[mid]);if(result<0)high=mid-1;else if(result>0)low=mid+1;else return mid;}
return-1;};}