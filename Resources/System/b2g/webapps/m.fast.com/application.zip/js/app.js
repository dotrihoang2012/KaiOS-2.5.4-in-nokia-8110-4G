window.addEventListener('DOMContentLoaded', function() {
  // We'll ask the browser to use strict code to help us catch errors earlier.
  // https://developer.mozilla.org/Web/JavaScript/Reference/Functions_and_function_scope/Strict_mode
  'use strict';

  var translate = navigator.mozL10n.get;

  // We want to wait until the localisations library has loaded all the strings.
  // So we'll tell it to let us know once it's ready.
  navigator.mozL10n.once(start);
  function start() {
    window.addEventListener('mozbrowsershowmodalprompt', (e)=>{
    var result = window.confirm(e.detail.message);
    e.detail.returnValue = result;
    e.detail.unblock();
   });
    
  }

  var browser = document.getElementById('browser');
});
