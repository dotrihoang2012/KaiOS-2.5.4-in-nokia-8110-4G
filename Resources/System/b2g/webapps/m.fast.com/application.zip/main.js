
// Opens the site in a remote browser full version frame, and close ourselves.
window.setTimeout(() => {
    window.open("https://fast.com/", '_blank');
    window.close();
}, 1000);
