'use strict';
var StackManager = {
    _stack: [],
    _current: -1,

    init: function() {
        window.addEventListener('appcreated', this);
        window.addEventListener('appopened', this);
        window.addEventListener('appterminated', this);
        window.addEventListener('homescreenopened', this);
        window.addEventListener('cardviewclosed', this);
    },

    get position() { return this._current; },
    set position(val) {
        val = parseInt(val);
        if (isNaN(val) || val < -1 || val >= this._stack.length) { return; }
        this._current = val;
    },

    snapshot: function() { return this._stack.slice(0); },

    outOfStack: function() {
        if (this._current < 0 || this._current >= this._stack.length) { return true; }
        var currentInStack = this._stack[this._current];
        if (!currentInStack) { return true; }
        var currentApp = Service.currentApp;
        if (!currentApp) { return true; }
        if (currentInStack === currentApp) { return false; }
        if (typeof currentInStack.getActiveWindow === 'function') {
            return currentInStack.getActiveWindow() !== currentApp;
        }
        return true;
    },

    handleEvent: function(e) {
        switch (e.type) {
            case 'appcreated':
                var app = e.detail;
                if (!app) { return; }
                if (app.manifest && app.manifest.role === 'system') { return; }
                if (app.name === 'FTU') { return; }
                if (app.previousWindow) { return; }
                if (!app.stayBackground) {
                    this._moveToTop(this._current);
                    this._stack.push(app);
                    this._current = this._stack.length - 1;
                }
                break;
            case 'appopened':
                var app = e.detail;
                if (!app) { return; }
                var root = (typeof app.getRootWindow === 'function') ? app.getRootWindow() : app;
                var idx = this._indexOfInstanceID(root.instanceID);
                if (idx !== undefined && idx !== this._current) {
                    this._moveToTop(idx);
                    this._current = this._stack.length - 1;
                }
                break;
            case 'homescreenopened':
                if (window.taskManager && window.taskManager.isShown()) { return; }
                this._current = -1;
                break;
            case 'appterminated':
                var instanceID = e.detail.instanceID;
                this._remove(instanceID);
                break;
            case 'cardviewclosed':
                if (e.detail && e.detail.newStackPosition !== undefined) {
                    this.position = e.detail.newStackPosition;
                }
                break;
        }
    },

    _moveToTop: function(index) {
        if (index === -1 || index >= this._stack.length) { return; }
        var app = this._stack.splice(index, 1)[0];
        this._current = this._stack.push(app) - 1;
    },

    _indexOfInstanceID: function(instanceID) {
        var result;
        this._stack.some(function(app, idx) {
            if (app.instanceID === instanceID) { result = idx; return true; }
        });
        return result;
    },

    _remove: function(instanceID) {
        for (var i = this._stack.length - 1; i >= 0; i--) {
            if (this._stack[i].instanceID === instanceID) {
                this._stack.splice(i, 1);
                if (i <= this._current && this._current >= 0) { this._current--; }
                return;
            }
        }
    }
};
StackManager.init();
