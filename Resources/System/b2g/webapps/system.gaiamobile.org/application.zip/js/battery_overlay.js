'use strict';
/* global PowerSave, ScreenManager, SettingsListener, Service, soundManager */

(function(exports) {

  function BatteryOverlay() {
    this.powerSave = new PowerSave();
    this.powerSave.start();
  }

  BatteryOverlay.prototype = {
    TOASTER_TIMEOUT: 5000,

    AUTO_SHUTDOWN_LEVEL: 0.00,
    CRITICAL_BATTERY_LEVEL: 0.05,
    CRITICAL_BATTERY_ID: 'criticalBattery',
    EMPTY_BATTERY_LEVEL: 0.15,
    TIMEOUT: 500,
    SOUNDFILE: 'resources/sounds/Connect_Power_MA.ogg',
    _battery: window.navigator.battery,
    _powersupply: window.navigator.powersupply,
    _notification: null,
    _batteryFullNotification: null,
    _criticalBatteryNotificationDisplayed: false,
    _powerSaveEnabled: false,

    checkBatteryDrainage: function bm_checkBatteryDrainage() {
      var battery = this._battery;
      if (!battery) {
        return;
      }
      if (battery.level <= this.AUTO_SHUTDOWN_LEVEL && !battery.charging) {
        // Fire a event to inform sleepMenu perform shutdown.
        window.dispatchEvent(new CustomEvent('batteryshutdown'));
      }
    },

    start: function bm_init() {
      var battery = this._battery;
      var powersupply = this._powersupply;
      if (battery) {
        // When the device is booted, check if the battery is drained. If so,
        // batteryshutdown would be triggered to inform sleepMenu shutdown.
        window.addEventListener('logohidden',
          this.checkBatteryDrainage.bind(this));

        battery.addEventListener('levelchange', this);
        battery.addEventListener('chargingchange', this);
      }

      if (powersupply) {
        powersupply.addEventListener('powersupplystatuschanged', this);
      }
      window.addEventListener('screenchange', this);
      SettingsListener.observe('audio.volume.notification', 1, (value) => {
        this.silent = value === 0;
      }, { forceClose: true });
      SettingsListener.observe('powersave.enabled', false, (value) => {
        this._powerSaveEnabled = !!value;
        if (this._criticalBatteryNotificationDisplayed) {
          this.updateCriticalBatteryNotification(true);
        }
      }, { forceClose: true });

      this._screenOn = true;
      this._wasEmptyBatteryNotificationDisplayed = false;

      this.displayIfNecessary();
      this.checkCriticalBatteryNotification();
      this.audio = new Audio();
    },

    handleEvent: function bm_handleEvent(evt) {
      var battery = this._battery;

      switch (evt.type) {
        case 'screenchange':
          this._screenOn = evt.detail.screenEnabled;
          this.displayIfNecessary();
          break;

        case 'levelchange':
          if (!battery) {
            return;
          }

          this.checkBatteryDrainage();
          this.displayIfNecessary();
          this.checkCriticalBatteryNotification();

          this.powerSave.onBatteryChange();

          if (this.shouldNotifyBatteryFull()) {
            this._batteryFullNotification = this.showBatteryFullNotification();
          }
          break;
        case 'chargingchange':
          this.powerSave.onBatteryChange();
          this.checkCriticalBatteryNotification();

          // We turn the screen on if needed in order to let
          // the user knows the device is charging

          if (battery && battery.charging) {
            this._wasEmptyBatteryNotificationDisplayed = false;
            this.removeCriticalBatteryNotification();

            if (this.audio && !this.audio.paused) {
              this.audio.pause();
            }
            if (!this.silent) {
              this.audio.src = this.SOUNDFILE;
              this.audio.mozAudioChannelType = 'notification';
              this.audio.play();
              window.setTimeout(() => {
                this.audio.pause();
                this.audio.removeAttribute('src');
                this.audio.load();
              }, this.TIMEOUT);
            }
            if (soundManager.vibrationEnabled) {
              navigator.vibrate(50);
            }
          } else {
            this.checkBatteryDrainage();
            this.displayIfNecessary();
          }
          break;
        case 'powersupplystatuschanged':
          if (!this._screenOn) {
            ScreenManager.turnScreenOn('powersupplystatuschanged');
          }

          this.removeBatteryFullNotification();
          break;
      }
    },

    _shouldWeDisplay: function bm_shouldWeDisplay() {
      var battery = this._battery;
      if (!battery) {
        return false;
      }

      return (!this._wasEmptyBatteryNotificationDisplayed &&
        !battery.charging &&
        battery.level < this.EMPTY_BATTERY_LEVEL &&
        this._screenOn);
    },

    displayIfNecessary: function bm_display() {
      if (!this._shouldWeDisplay()) {
        return;
      }

      var isCritical = Math.round(this._battery.level * 100) <= 5;
      var l10nId = isCritical ?
        'critical-battery-low-toast' :
        'battery-almost-empty-plug-in-your-charger';
      Service.request('SystemToaster:show', {
        text: navigator.mozL10n.get(l10nId)
      });
    },

    checkCriticalBatteryNotification: function() {
      var battery = this._battery;
      if (!battery) {
        return;
      }
      var isCritical = !battery.charging && Math.round(battery.level * 100) <= 5;
      if (isCritical) {
        if (!this._criticalBatteryNotificationDisplayed) {
          this._criticalBatteryNotificationDisplayed = true;
          this.updateCriticalBatteryNotification(false);
        }
      } else if (this._criticalBatteryNotificationDisplayed) {
        this.removeCriticalBatteryNotification();
      }
    },

    updateCriticalBatteryNotification: function(noNotify) {
      navigator.mozL10n.once(() => {
        if (!this._criticalBatteryNotificationDisplayed) {
          return;
        }
        var _ = navigator.mozL10n.get;
        var title = _('critical-battery-notification-title') || 'Critical Battery Low';
        var body = _('critical-battery-notification-body') ||
          'Battery is critically low. Please charge your phone now.';
        var isPowerSaveOn = !!(this._powerSaveEnabled ||
          (this.powerSave && this.powerSave._powerSaveEnabled));
        var info = {
          id: this.CRITICAL_BATTERY_ID,
          title: title,
          text: body,
          icon: 'style/icons/low_battery.png',
          type: 'desktop-notification',
          inoperable: isPowerSaveOn,
          callback: () => {
            if (this._powerSaveEnabled ||
              (this.powerSave && this.powerSave._powerSaveEnabled)) {
              return;
            }
            window.setTimeout(() => {
              this.showEnablePowerSaveDialog();
            }, 50);
          }
        };
        if (noNotify) {
          info.noNotify = true;
        }
        Service.request('NotificationStore:add', info);
      });
    },

    showEnablePowerSaveDialog: function() {
      var _ = navigator.mozL10n.get;
      Service.request('DialogService:show', {
        header: _('critical-battery-notification-title') || 'Critical Battery Low',
        content: _('critical-battery-enable-powersave-prompt') ||
          'Critical battery low. Do you want to enable battery saver?',
        type: 'confirm',
        ok: 'yes',
        cancel: 'no',
        translated: true,
        onOk: () => {
          this.powerSave.setMozSettings({'powersave.enabled': true});
        },
        onCancel: () => {}
      });
    },

    removeCriticalBatteryNotification: function() {
      if (this._criticalBatteryNotificationDisplayed) {
        this._criticalBatteryNotificationDisplayed = false;
        Service.request('NotificationStore:remove', this.CRITICAL_BATTERY_ID);
      }
    },

    /**
     * Check if the battery is fully charged or not.
     */
    shouldNotifyBatteryFull: function() {
      var battery = this._battery;
      if (!battery) {
        return false;
      }

      var powersupply = this._powersupply;
      if (!powersupply) {
        return false;
      }

      return (battery.level === 1 &&
              powersupply.powerSupplyOnline &&
              this._batteryFullNotification === null);
    },

    /**
     * Display the fully charged notification.
     */
    showBatteryFullNotification: function() {
      navigator.mozL10n.once(() => {
        if (!this._batteryFullNotification) {
          return;
        }
        var title = navigator.mozL10n.get('battery-full-title') || '';
        var body = navigator.mozL10n.get('battery-full-body') || '';
        Service.request('NotificationStore:add', {
          id: 'batteryFull',
          title: title,
          text: body,
          icon: 'style/notifications/images/battery_full.png',
          type: 'desktop-notification',
          inoperable: true
        });
      });

      return {
        close: function() {
          Service.request('NotificationStore:remove', 'batteryFull');
        }
      };
    },

    /**
     * Remove the battery full notification if it is exists.
     */
    removeBatteryFullNotification: function() {
      if (this._batteryFullNotification !== null) {
        this._batteryFullNotification.close();
        this._batteryFullNotification = null;
      }
    }
  };

  exports.BatteryOverlay = BatteryOverlay;

}(window));
