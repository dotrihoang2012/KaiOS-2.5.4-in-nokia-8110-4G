define(['require', 'shared/settings_listener', 'modules/settings_panel',
  'panels/accessibility_screenreader/confirm_dialog'],
function(require) {
  var SettingsListener = require('shared/settings_listener');
  var SettingsPanel = require('modules/settings_panel');
  var KEY_SCREENREADER = 'accessibility.screenreader';
  var KEY_VOLUME = 'accessibility.screenreader-volume';
  var KEY_RATE = 'accessibility.screenreader-rate';

  return function() {
    var toggleInput;

    function _refreshNavigation(panel) {
      var observer = new MutationObserver(function() {
        observer.disconnect();
        var controls = panel.querySelectorAll('li:not([hidden]):not(.non-focus)');
        NavigationMap._controls = controls;
        NavigationMap.update();
        panel.querySelectorAll('.focus').forEach(function(el) {
          el.classList.remove('focus');
        });
        if (controls[0]) {
          controls[0].classList.add('focus');
        }
      });
      observer.observe(panel, {
        subtree: true, attributes: true, attributeFilter: ['hidden']
      });
    }

    function _addSliderKeyHandler(slider) {
      var li = slider.closest('li');
      if (!li) return;
      li.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowRight') {
          slider.value = Math.min(parseFloat(slider.max),
            parseFloat(slider.value) + parseFloat(slider.step));
          slider.dispatchEvent(new Event('change', { bubbles: true }));
          e.stopPropagation();
        } else if (e.key === 'ArrowLeft') {
          slider.value = Math.max(parseFloat(slider.min),
            parseFloat(slider.value) - parseFloat(slider.step));
          slider.dispatchEvent(new Event('change', { bubbles: true }));
          e.stopPropagation();
        }
      });
    }

    return SettingsPanel({
      onInit: function(panel) {
        navigator.mozL10n.translateFragment(panel);

        // Ensure the ul is visible by setting the show-settings key
        var lock = SettingsListener.getSettingsLock();
        lock.set({'accessibility.screenreader-show-settings': true});

        toggleInput = panel.querySelector('#screenreader-enable input');
        toggleInput.onchange = function() {
          var lock = SettingsListener.getSettingsLock();
          var obj = {};
          obj[KEY_SCREENREADER] = toggleInput.checked;
          lock.set(obj);
          _refreshNavigation(panel);
        };
        SettingsListener.observe(KEY_SCREENREADER, false, function(value) {
          toggleInput.checked = value;
        });

        var volumeSlider = panel.querySelector('input[name="' + KEY_VOLUME + '"]');
        var rateSlider = panel.querySelector('input[name="' + KEY_RATE + '"]');

        if (volumeSlider) {
          SettingsListener.observe(KEY_VOLUME, 0.5, function(value) {
            volumeSlider.value = value;
          });
          _addSliderKeyHandler(volumeSlider);
        }

        if (rateSlider) {
          SettingsListener.observe(KEY_RATE, 0, function(value) {
            rateSlider.value = value;
          });
          _addSliderKeyHandler(rateSlider);
        }
      }
    });
  };
});
