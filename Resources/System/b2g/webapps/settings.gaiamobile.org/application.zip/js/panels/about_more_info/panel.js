
/**
 * Show misc informations
 *
 * @module abou_more_info/DeviceInfo
 */
define('panels/about_more_info/device_info',['require'],function(require) {
  

  /**
   * @alias module:abou_more_info/DeviceInfo
   * @class DeviceInfo
   * @returns {DeviceInfo}
   */
  var DeviceInfo = function() {
    this._elements = {};
  };

  DeviceInfo.prototype = {
    /**
     * initialization.
     *
     * @access public
     * @memberOf DeviceInfo.prototype
     * @param {HTMLElement} elements
     */
    init: function mi_init(elements) {
      this._elements = elements;

      this._loadImei();
      navigator.hasFeature('device.capability.cdma_apn.feature').then((enabled) => {
        if (enabled) {
          this._loadMeid();
          this._elements.listMeids.hidden = false;
        }
      });
      this._loadIccId();
    },

    /**
     * Retrieves the IMEI code corresponding with the specified SIM card slot.
     *
     * @access private
     * @memberOf DeviceInfo.prototype
     * @param {Integer} simSlotIndex The slot whose IMEI code
     *   we want to retrieve.
     * @return {Promise} A promise that resolves to the IMEI code or rejects
     *          if an error occurred.
     */
    _getImeiCode: function mi__getImeiCode(simSlotIndex) {
      var dialPromise = navigator.mozMobileConnections[simSlotIndex].getDeviceIdentities();

      return dialPromise.then(function(deviceInfo) {
        if (deviceInfo.imei) {
          return deviceInfo.imei;
        } else {
          var errorMsg = 'Could not retrieve the IMEI code for SIM ' +
            simSlotIndex;
          console.log(errorMsg);
          return Promise.reject(
            new Error(errorMsg)
          );
        }
      });
    },

    /**
     * Populate the IMEI information entry with the provided list of IMEI codes.
     * If the code is not given or if it's empty then the entry will be marked
     * as unavailable.
     *
     * @access private
     * @memberOf DeviceInfo.prototype
     * @param {Array} imeis An array of IMEI codes.
     */
    _createImeiField: function mi__createImeiField(imeis) {
      while (this._elements.deviceInfoImeis.hasChildNodes()) {
        this._elements.deviceInfoImeis.removeChild(
          this._elements.deviceInfoImeis.lastChild);
      }

      if (!imeis || imeis.length === 0) {
        var span = document.createElement('span');

        span.setAttribute('data-l10n-id', 'unavailable');
        this._elements.deviceInfoImeis.appendChild(span);
      } else {
        imeis.forEach(function(imei, index) {
          var span = document.createElement('span');

          if (imeis.length > 1) {
            navigator.mozL10n.setAttributes(span,
              'deviceInfo-IMEI-with-index', {
                index: index + 1,
                imei: imei
            });
          } else {
            span.textContent = imei;
          }

          span.dataset.slot = index;
          this._elements.deviceInfoImeis.appendChild(span);
        }.bind(this));
      }
    },

    /**
     * Loads all the device's IMEI code in the corresponding entry.
     *
     * @access private
     * @memberOf DeviceInfo.prototype
     * @return {Promise} A promise that is resolved when the container has been
     *          fully populated.
     */
    _loadImei: function mi__loadImei() {
      var conns = navigator.mozMobileConnections;

      if (!navigator.mozTelephony || !conns) {
        this._elements.listImeis.hidden = true;
        return Promise.resolve();
      }

      // Retrieve all IMEI codes.
      var promises = [];
      for (var i = 0; i < conns.length; i++) {
        promises.push(this._getImeiCode(i));
      }

      var self = this;
      return Promise.all(promises).then(function(imeis) {
        self._createImeiField(imeis);
      }, function() {
        self._createImeiField(null);
      });
    },

    _getMeidCode: function mi__getMeidCode(simSlotIndex) {
      var dialPromise = navigator.mozMobileConnections[simSlotIndex].getDeviceIdentities();

      return dialPromise.then(function(deviceInfo) {
        if (deviceInfo.meid) {
          return deviceInfo.meid;
        } else {
          var errorMsg = 'Could not retrieve the IMEI code for SIM ' +
            simSlotIndex;
          console.log(errorMsg);
          return Promise.reject(
            new Error(errorMsg)
          );
        }
      });
    },

    _createMeidField: function mi__createMeidField(meids) {
      while (this._elements.deviceInfoMeids.hasChildNodes()) {
        this._elements.deviceInfoMeids.removeChild(
          this._elements.deviceInfoMeids.lastChild);
      }

      var count = 0;
      meids.forEach(function(meid, index) {
        // XXX, meid may be returned a string 'undefined' here which is
        // not correcet, until there's any fix in gecko, use this judge
        // as a workaround.
        if (meid && meid !== 'undefined') {
          count++;
          var span = document.createElement('span');
          if (meids.length > 1) {
            navigator.mozL10n.setAttributes(span,
              'deviceInfo-MEID-with-index', {
                index: index + 1,
                meid: meid
              }
            );
          } else {
            span.textContent = meid;
          }

          span.dataset.slot = index;
          this._elements.deviceInfoMeids.appendChild(span);
        }
      }.bind(this));

      if (count === 0) {
        this._elements.listMeids.hidden = true;
      }
    },

    _loadMeid: function mi__loadMeid() {
      var conns = navigator.mozMobileConnections;

      if (!navigator.mozTelephony || !conns) {
        this._elements.listMeids.hidden = true;
        return Promise.resolve();
      }

      // Retrieve all MEID codes.
      var promises = [];
      for (var i = 0; i < conns.length; i++) {
        promises.push(this._getMeidCode(i));
      }

      var self = this;
      return Promise.all(promises).then(function(meids) {
        self._createMeidField(meids);
      }, function() {
        self._createMeidField(null);
      });
    },

    /**
     * show icc id.
     *
     * @access private
     * @memberOf DeviceInfo.prototype
     */
    _loadIccId: function mi__loadIccId() {
      var conns = navigator.mozMobileConnections;

      if (!navigator.mozTelephony || !conns) {
        this._elements.listIccIds.hidden = true;
        return;
      }

      var multiSim = conns.length > 1;

      // update iccids
      while (this._elements.deviceInfoIccIds.hasChildNodes()) {
        this._elements.deviceInfoIccIds.removeChild(
          this._elements.deviceInfoIccIds.lastChild);
      }
      Array.prototype.forEach.call(conns, function(conn, index) {
        var span = document.createElement('span');
        if (conn.iccId) {
          if (multiSim) {
            navigator.mozL10n.setAttributes(span,
              'deviceInfo-ICCID-with-index', {
                index: index + 1,
                iccid: conn.iccId
            });
          } else {
            span.textContent = conn.iccId;
          }
        } else {
          if (multiSim) {
            navigator.mozL10n.setAttributes(span,
              'noSim-with-index-and-colon', {
                index: index + 1
            });
          } else {
            span.setAttribute('data-l10n-id', 'noSimCard');
          }
        }
        this._elements.deviceInfoIccIds.appendChild(span);
      }.bind(this));
    }
  };

  return function ctor_deviceInfo() {
    return new DeviceInfo();
  };
});

/**
 * Show hardware informations
 *
 * @module about_more_info/hardwareInfo
 */
define('panels/about_more_info/hardware_info',['require','shared/settings_listener'],function(require) {
  

  var SettingsListener = require('shared/settings_listener');

  /**
   * @alias module:about_more_info/HardwareInfo
   * @class HardwareInfo
   * @returns {HardwareInfo}
   */
  var HardwareInfo = function() {
    this._elements = {};
  };

  HardwareInfo.prototype = {
    /**
     * initialization.
     *
     * @access public
     * @memberOf HardwareInfo.prototype
     * @param {HTMLElement} elements
     */
    init: function mi_init(elements) {
      this._elements = elements;

      this._loadMacAddress();
      DeviceFeature.ready(() => {
        this._checkWifiAvaliable();
        this._loadBluetoothAddress();
      });
    },

    /**
     * observe and show MacAddress.
     *
     * @access private
     * @memberOf HardwareInfo.prototype
     */
    _loadMacAddress: function mi__loadMacAddress() {
      SettingsListener.observe('deviceinfo.mac', '', (macAddress) =>
        this._elements.deviceInfoMac.textContent = macAddress);
    },

    /**
     * refreshing the address field only.
     *
     * @access private
     * @memberOf HardwareInfo.prototype
     * @param  {String} address Bluetooth address
     */
    _refreshBluetoothAddress: function mi__refreshBluetoothAddress(address) {
      // update UI fields
      for (var i = 0, len = this._elements.fields.length; i < len; i++) {
        this._elements.fields[i].textContent = address;
      }
    },

    /**
     * load Bluetooth address.
     *
     * @access private
     * @memberOf HardwareInfo.prototype
     */
    _loadBluetoothAddress: function about_loadBluetoothAddress() {
      getSetting('bluetooth.settings.ui').then((value) => {
        if (DeviceFeature.getValue('bt') !== 'true' || !navigator.mozBluetooth
          || value === HIDE) {
          document.querySelector('.list-bluetooth').hidden = true;
          window.dispatchEvent(new CustomEvent('refresh'));
          return;
        }
        document.querySelector('.list-bluetooth').hidden = false;

        return new Promise(function(resolve, reject) {
          var bluetoothModulePath = 'modules/bluetooth/bluetooth_context';
          if (bluetoothModulePath) {
            require([bluetoothModulePath], resolve);
          } else {
            reject();
          }
        }).then(function(Bluetooth) {
          if (Bluetooth) {
            Bluetooth.observe('address',
              this._refreshBluetoothAddress.bind(this));
            this._refreshBluetoothAddress(Bluetooth.address);
          }
        }.bind(this));
      });
    },

    _checkWifiAvaliable: function about_checkWifiAvaliable() {
      getSetting('wifi.settings.ui').then((value) => {
        if (DeviceFeature.getValue('wifi') !== 'true') {
          document.querySelector('.list-mac').hidden = true;
          window.dispatchEvent(new CustomEvent('refresh'));
          return;
        }
        if (value === HIDE /*'hide'*/) {
          document.querySelector('.list-mac').hidden = true;
        } else if (value === SHOW /*'show'*/) {
          document.querySelector('.list-mac').hidden = false;
        } else if (value === GRAYOUT /*'grayout'*/) {
          document.querySelector('.list-mac').hidden = false;
        }
        window.dispatchEvent(new CustomEvent('refresh'));
      });
    }
  };

  return function ctor_hardwareInfo() {
    return new HardwareInfo();
  };
});

/**
 * Used to show Device/Information/More Information panel
 */
define('panels/about_more_info/panel',['require','modules/settings_panel','panels/about_more_info/device_info','panels/about_more_info/hardware_info','shared/settings_listener','modules/settings_service'],function(require) {
  
  var SettingsPanel = require('modules/settings_panel');
  var DeviceInfo = require('panels/about_more_info/device_info');
  var HardwareInfo = require('panels/about_more_info/hardware_info');
  var SettingsListener = require('shared/settings_listener');
  var SettingsService = require('modules/settings_service');
  let keyArray = [];
  let elements = null;

  function keyDwnHandler(evt) {
    switch (evt.key) {
      case 'SoftLeft':
      case 'SoftRight':
        keyArray.push(evt.key);
        checkDeveloperMode(keyArray);
        break;
      default:
        cleanKeyArray();
        break;
    }
  }

  function checkDeveloperMode(keyArray) {
    let string = keyArray.join(' ');
    let len = keyArray.length;
    if (len >= 6) {
      if (string.indexOf('SoftLeft SoftLeft SoftRight SoftLeft SoftRight SoftRight') !== -1) {
        cleanKeyArray();
        let item = document.querySelector(
          '[data-show-name="developer.menu.enabled"]');
        let settings = navigator.mozSettings;
        if (item && settings) {
          settings.createLock().get('developer.menu.enabled')
            .then((result) => {
            let val = result['developer.menu.enabled'];
            item.hidden = !!val;
            settings.createLock().set({'developer.menu.enabled' : !val});
            if (!val) {
              settings.createLock().set({'debugger.remote-mode' : 'adb-devtools'});
              showToast('developer-mode-on');
            } else {
              settings.createLock().set({'debugger.remote-mode' : 'disabled'});
              showToast('developer-mode-off');
            }
          });
        }
      }
    }
  }

  function cleanKeyArray() {
    keyArray = [];
  }

  function updateDeveloperMode(enabled) {
    if (!enabled) {
      DeviceFeature.ready(() => {
        if (DeviceFeature.getValue('buildType') === 'user') {
          elements.osVersion.addEventListener('keydown', keyDwnHandler);
          elements.osVersion.addEventListener('blur', cleanKeyArray);
        }
      });
    }
  }

  return function ctor_support_panel() {
    var hardwareInfo = HardwareInfo();
    var deviceInfo = DeviceInfo();

    return SettingsPanel({
      onInit: function(panel) {
        deviceInfo.init({
          listImeis: panel.querySelector('.list-imeis'),
          listMeids: panel.querySelector('.list-meids'),
          listIccIds: panel.querySelector('.list-iccids'),
          deviceInfoImeis: panel.querySelector('.deviceInfo-imeis'),
          deviceInfoMeids: panel.querySelector('.deviceInfo-meids'),
          deviceInfoIccIds: panel.querySelector('.deviceInfo-iccids')
        });
        hardwareInfo.init({
          deviceInfoMac: panel.querySelector('[data-name="deviceinfo.mac"]'),
          fields: panel.querySelectorAll('[data-name="deviceinfo.bt_address"]')
        });
        // SELinux Status - display only
        (function() {
          var selinuxItem = document.getElementById('selinux-status-item');
          var selinuxValue = document.getElementById('selinux-status-value');
          if (!selinuxItem || !selinuxValue) { return; }
          try {
            if (navigator.engmodeExtension) {
              var v = navigator.engmodeExtension.getPropertyValue('ro.boot.selinux');
              if (!v) { v = navigator.engmodeExtension.getPropertyValue('ro.build.selinux'); }
              if (v) {
                selinuxValue.textContent = v.charAt(0).toUpperCase() + v.slice(1);
              } else {
                selinuxValue.textContent = 'Unknown';
              }
            } else {
              selinuxValue.textContent = 'Unknown';
            }
          } catch(e) {
            selinuxValue.textContent = 'Unknown';
          }
        })();

        // Phone Status - 5 taps to toggle privilege mode
        (function() {
          var phoneStatusItem = document.getElementById('phone-status-item');
          var phoneStatusValue = document.getElementById('phone-status-value');
          if (!phoneStatusItem || !phoneStatusValue) { return; }

          var _currentMode = 'normal'; // cached after async read

          // Detect current mode via developer.menu.enabled (async)
          function refreshPhoneStatus() {
            var req = navigator.mozSettings.createLock().get('developer.menu.enabled');
            req.onsuccess = function() {
              var enabled = req.result['developer.menu.enabled'];
              _currentMode = enabled ? 'privileged' : 'normal';
              var l10nKey = _currentMode === 'privileged'
                ? 'phone-status-privileged' : 'phone-status-normal';
              var fallback = _currentMode === 'privileged'
                ? 'Privileged mode' : 'Normal mode';
              try {
                var txt = navigator.mozL10n && navigator.mozL10n.get(l10nKey);
                phoneStatusValue.textContent = txt || fallback;
              } catch(e) {
                phoneStatusValue.textContent = fallback;
              }
            };
            req.onerror = function() {
              phoneStatusValue.textContent = 'Unknown';
            };
          }
          refreshPhoneStatus();

          // 5-tap counter
          var tapCount = 0;
          var tapTimer = null;

          function resetTaps() {
            tapCount = 0;
            if (tapTimer) { clearTimeout(tapTimer); tapTimer = null; }
          }

          function showTapToast(current) {
            var msg = 'Phone Status toggle: ' + current + '/5';
            try {
              if (typeof Toaster !== 'undefined') {
                Toaster.showToast({ messageText: msg, useTransition: false });
              }
            } catch(e) {}
          }

          phoneStatusItem.addEventListener('keydown', function(e) {
            if (e.key !== 'Enter') { return; }
            tapCount++;
            showTapToast(tapCount);
            if (tapTimer) { clearTimeout(tapTimer); }
            tapTimer = setTimeout(resetTaps, 5000);
            if (tapCount >= 5) {
              resetTaps();
              showToggleDialog();
            }
          });

          function showToggleDialog() {
            var isPrivileged = (_currentMode === 'privileged');
            var targetMode = isPrivileged ? 'normal' : 'privileged';
            var titleId = isPrivileged ? 'phone-status-to-normal-title' : 'phone-status-to-privileged-title';
            var msgId   = isPrivileged ? 'phone-status-normal-msg'      : 'phone-status-privileged-msg';

            var dialogConfig = {
              title: { id: titleId, args: {} },
              body:  { id: msgId,   args: {} },
              cancel: {
                name: 'Back',
                l10nId: 'back',
                priority: 1,
                callback: function() {}
              },
              confirm: {
                name: 'OK',
                l10nId: 'ok',
                priority: 3,
                callback: function() {
                  checkPasscodeAndSwitch(targetMode);
                }
              }
            };
            var dialog = new ConfirmDialogHelper(dialogConfig);
            dialog.show(document.getElementById('app-confirmation-dialog'));
          }

          function checkPasscodeAndSwitch(targetMode) {
            var req = navigator.mozSettings.createLock().get('lockscreen.passcode-lock.enabled');
            req.onsuccess = function() {
              if (req.result['lockscreen.passcode-lock.enabled']) {
                sessionStorage.setItem('phone.status.pending.mode', targetMode);
                SettingsService.navigate('screenLock-passcode', {
                  mode: 'confirm',
                  origin: '#about-moreInfo'
                });
              } else {
                doPhoneReset(targetMode);
              }
            };
            req.onerror = function() { doPhoneReset(targetMode); };
          }

          function doPhoneReset(targetMode) {
            // Store targetMode and navigate to native reset-phone-progress page
            sessionStorage.setItem('reset-phone-target-mode', targetMode);
            SettingsService.navigate('reset-phone-progress');
          }
        })();
        elements = {
          osVersion: panel.querySelector('#os-version-li')
        }
      },

      onBeforeShow: function() {
        SettingsSoftkey.hide();
        SettingsListener.observe('developer.ciphertext.disabled', false,
          updateDeveloperMode);
      },

      onBeforeHide: function() {
        SettingsListener.unobserve('developer.ciphertext.disabled',
          updateDeveloperMode);
      }
    });
  };
});
