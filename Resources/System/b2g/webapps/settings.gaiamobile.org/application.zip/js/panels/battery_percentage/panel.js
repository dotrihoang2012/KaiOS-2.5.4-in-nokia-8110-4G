define('panels/battery_percentage/panel',['require','modules/settings_panel','shared/settings_listener'],function(require) {

  var SettingsPanel = require('modules/settings_panel');
  var SettingsListener = require('shared/settings_listener');

  return function ctor_battery_percentage_panel() {
    var listElements = null;

    function _initSoftKey() {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: { l10nId: 'message' },
        items: [{ name: 'Select', l10nId: 'select', priority: 2, method: function() {} }]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function _showToast() {
      showToast('changessaved');
    }

    return SettingsPanel({
      onInit: function bp_onInit(panel) {
        listElements = panel.querySelectorAll('li');
        this.bpSelect = panel.querySelector('#battery-percentage-select');
        SettingsListener.observe('statusbar.battery.percentage', false, function(value) {
          if (this.bpSelect) {
            this.bpSelect.value = value;
          }
        }.bind(this));
      },

      onBeforeShow: function bp_onBeforeShow(panel) {
        navigator.mozL10n.translateFragment(panel);
        _initSoftKey();
        ListFocusHelper.addEventListener(listElements);
        this.bpSelect.addEventListener('change', _showToast);
      },

      onBeforeHide: function bp_onBeforeHide() {
        ListFocusHelper.removeEventListener(listElements);
        this.bpSelect.removeEventListener('change', _showToast);
      },

      onShow: function() {},
      onHide: function() {}
    });
  };
});
